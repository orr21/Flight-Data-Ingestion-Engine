import json
from datetime import timedelta
from loguru import logger

from pyspark.sql import SparkSession, functions as F

from .motor_ingesta import MotorIngesta
from .agregaciones import aniade_hora_utc, aniade_intervalos_por_aeropuerto

class FlujoDiario:

    def __init__(self, config_file: str):
        """
        Carga la configuración y obtiene/crea la SparkSession.

        :param config_file: Ruta a un fichero JSON con, al menos, las claves:
            - "output_table": nombre de la tabla externa donde escribir (string)
            - "output_path":  ruta del almacenamiento para la tabla externa (string)
            - "output_partitions": número de particiones al escribir (int)
            - Cualquier otra clave usada por el motor de ingesta (formatos, esquemas, etc.)
        """
        self.spark = SparkSession.builder.getOrCreate()

        with open(config_file, "r", encoding="utf-8") as f:
            self.config = json.load(f)

    def procesa_diario(self, data_file: str):
        """
        Orquesta el procesamiento diario y escribe la tabla externa particionada por FlightDate.

        :param data_file: Ruta al fichero JSON del día.
        """
        try:

            motor_ingesta = MotorIngesta(self.config)
            flights_df = motor_ingesta.ingesta_fichero(data_file).cache()

            flights_with_utc = aniade_hora_utc(self.spark, flights_df)

            dia_actual = flights_with_utc.first().FlightDate
            dia_previo = dia_actual - timedelta(days=1)
            try:
                flights_previo = self.spark.read.table(self.config["output_table"]).where(F.col("FlightDate") == dia_previo)
                logger.info(f"Leída partición del día {dia_previo} con éxito")
            except Exception as e:
                logger.info(f"No se han podido leer datos del día {dia_previo}: {str(e)}")
                flights_previo = None

            if flights_previo:
                df_unido = flights_previo.unionByName(flights_with_utc, allowMissingColumns=True)

                df_unido.write.mode("overwrite").saveAsTable("tabla_provisional")
                df_unido = self.spark.read.table("tabla_provisional")

            else:
                df_unido = flights_with_utc

            df_with_next_flight = aniade_intervalos_por_aeropuerto(df_unido)
            
            (
            df_with_next_flight
                .repartition(int(self.config.get("output_partitions", 1)), F.col("FlightDate"))
                .write
                .mode("overwrite")
                .option("partitionOverwriteMode", "dynamic")
                .partitionBy("FlightDate")
                .saveAsTable(self.config["output_table"])
            )

            self.spark.sql("DROP TABLE IF EXISTS tabla_provisional")

        except Exception as e:
            logger.error(f"No se pudo escribir la tabla del fichero {data_file}")
            raise e


if __name__ == "__main__":
    spark = SparkSession.builder.getOrCreate()
    ruta_config = "../config/config.json"
    ruta_fichero = "../data/landing/flights_2023-01-01.json"

    flujo = FlujoDiario(ruta_config)
    flujo.procesa_diario(ruta_fichero)

    # Recuerda que puedes crear el wheel ejecutando en la línea de comandos: python setup.py bdist_wheel
