from pathlib import Path

from pyspark.sql import SparkSession, DataFrame as DF, functions as F, Window
import pandas as pd


def aniade_hora_utc(spark: SparkSession, df: DF) -> DF:
    """
    Añade la marca temporal UTC del vuelo en una columna 'FlightTime'.

    Reglas:
    - Une por IATA origen contra un catálogo local `resources/timezones.csv`
      con columnas: iata_code, iana_tz (zona horaria IANA).
    - Construye la hora local a partir de FlightDate (yyyy-MM-dd) + DepTime (HHmm),
      tolerando valores de DepTime de 3 o 4 dígitos (se rellena con '0' a la izquierda).
    - Convierte a UTC con `to_utc_timestamp`.

    :param spark: SparkSession activa.
    :param df: DataFrame con columnas 'FlightDate' (date/string), 'DepTime' (int/string HHmm) y 'Origin' (IATA).
    :return: DF con nueva columna 'FlightTime' en UTC (timestamp). Si no hay zona horaria,
             'FlightTime' quedará NULL.
    """
    path_timezones = str(Path(__file__).parent / "resources" / "timezones.csv")
    timezones_df = (
        spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .csv(path_timezones)
        .select("iata_code", "iana_tz")
    )

    df_with_tz = df.join(timezones_df, df["Origin"] == timezones_df["iata_code"], "left")

    dep_str = F.lpad(F.col("DepTime").cast("string"), 4, "0")
    
    flight_time_str = F.concat(
        F.col("FlightDate").cast("string"),
        F.lit(" "),
        dep_str.substr(1, 2),  # HH
        F.lit(":"),
        dep_str.substr(3, 2),  # mm
    )

    df_local = df_with_tz.withColumn("FlightTime", F.to_timestamp(flight_time_str, "yyyy-MM-dd HH:mm"))

    df_utc = df_local.withColumn(
        "FlightTime",
        F.expr("to_utc_timestamp(FlightTime, iana_tz)")
    )

    return df_utc.drop("iata_code").drop("iana_tz")   


def aniade_intervalos_por_aeropuerto(df: DF) -> DF:
    """
    Añade información del siguiente vuelo por aeropuerto de origen, ordenado por 'FlightTime'.

    Columnas añadidas:
      - FlightTime_next: timestamp del siguiente vuelo desde el mismo 'Origin'
      - Airline_next:    código de aerolínea del siguiente vuelo
      - diff_next:       diferencia en segundos entre FlightTime_next y FlightTime
                         (int, NULL si no hay siguiente vuelo en el día)

    :param df: DataFrame con columnas 'Origin', 'FlightTime' y 'Reporting_Airline'.
    :return: DF con columnas anteriores añadidas.
    """
    w = Window.partitionBy("Origin").orderBy(F.col("FlightTime").asc())

    out = (
        df
        .withColumn("FlightTime_next", F.lead("FlightTime").over(w))
        .withColumn("Airline_next", F.lead("Reporting_Airline").over(w))
        .withColumn(
            "diff_next",
            (F.col("FlightTime_next").cast("long") - F.col("FlightTime").cast("long")).cast("bigint")
        )
    )
    return out

